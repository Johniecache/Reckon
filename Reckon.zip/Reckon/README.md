# Reckon

A lightweight live DPS meter for **The Elder Scrolls Online**. It shows your own DPS accurately, per-player DPS for anyone sharing through the Hodor / LibGroupCombatStats system, and a rough estimate for everyone else — all in a small, draggable bar window.

It's client-side: you don't need anyone else to have it installed. (Seeing *other* players' exact numbers does require them to be sharing — see [Compatibility](#compatibility).)

## What it does

- **Your DPS** — read straight from your own combat events (including pet/companion). Always accurate.
- **Per-player DPS** — an exact bar for each group member running Hodor Reflexes or any LibGroupCombatStats addon.
- **Unknown ~** — everyone you can't measure individually, combined: `estimated group total − (you + everyone sharing)`. The group total is estimated from the target's health draining, so this fills in for players who don't have a compatible addon. It's a rough proxy, not a parse, and it sharpens toward a single player as more of the group shares.
- **Two views** — a per-player breakdown, or a compact "You vs Others" group estimate. Toggle anytime with `/reckon mode`.
- Updates live during combat, with an optional fight summary printed to chat.

## Install

1. Download this repo (**Code → Download ZIP**, or `git clone`).
2. The addon folder must be named exactly **`Reckon`** and contain `Reckon.txt` and `Reckon.lua`. A ZIP extracts as `Reckon-main` — **rename it to `Reckon`** (ESO requires the folder name to match the manifest).
3. Copy that `Reckon` folder into your AddOns directory:
   - **Windows:** `Documents\Elder Scrolls Online\live\AddOns\`
   - **Mac:** `~/Documents/Elder Scrolls Online/live/AddOns/`
4. Launch ESO, open **Add-Ons** from the menu, enable **Reckon**, and reload the UI. If it shows as *out of date*, tick **Allow out of date add-ons** (or bump the `## APIVersion:` line in `Reckon.txt` to your current client version).
5. Type `/reckon test` in chat to preview it and drag it into position.

## Dependencies

Reckon runs standalone in **group-estimate mode** with no dependencies. To unlock **per-player** bars, install these (easiest via [Minion](https://minion.mmoui.com/), which pulls all three automatically):

- [LibGroupCombatStats](https://www.esoui.com/downloads/info4024-LibGroupCombatStats.html)
- [LibCombat](https://www.esoui.com/downloads/info2528-LibCombat.html)
- [LibGroupBroadcast](https://www.esoui.com/downloads/fileinfo.php?id=1337)

Optional: **LibAddonMenu-2.0** (on ESOUI / via Minion) for a settings panel. Without it, use the slash commands below.

## Compatibility

**Works with**

- **Hodor Reflexes** — Reckon reads its shared DPS for the per-player view. They run side by side.
- Any addon built on **LibGroupCombatStats** — same shared-data channel.
- **Combat Metrics** and other self-analysis addons — independent, no conflict.

Reckon only ever shares data *through* LibGroupCombatStats — the sanctioned, rate-limited group channel — so it does **not** cause the "two addons broadcasting at once" disconnects that older redundant damage-sharers could.

**Not supported / limitations**

- **Console** — ESO doesn't support custom Lua addons on console. PC/Mac only.
- **Exact DPS for non-sharers** — impossible; the game never sends their damage to your client. They're folded into the `Unknown ~` estimate instead.
- **Trash / multi-target** — the group estimate tracks bosses and your reticle target, so it's only meaningful on a single boss or a target dummy. Per-player bars (from sharers) are unaffected.

## Commands

| Command | Action |
| --- | --- |
| `/reckon` | Show / hide the window |
| `/reckon mode` | Switch per-player ⟷ group estimate |
| `/reckon share` | Toggle sharing your DPS (then `/reloadui`) |
| `/reckon summary` | Toggle the end-of-fight chat line |
| `/reckon lock` · `/reckon unlock` | Lock / unlock dragging |
| `/reckon scale <0.5–2.0>` | Resize the window |
| `/reckon reset` | Recenter the window |
| `/reckon test` | Preview with sample data |

## License

[MIT](LICENSE) — swap it for whatever you prefer.
